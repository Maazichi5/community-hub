# Community Hub — starter project

A cross-platform starter for a public social network with a Next.js web app, an Expo Android app, and Supabase authentication/database.

## Included
- Monorepo layout for web and mobile
- Basic sign-in / sign-up screens
- Shared Supabase client setup
- Initial database schema and row-level security policies
- Environment variable examples

## Before running
1. Create a Supabase project.
2. Copy the project URL and anon/publishable key into each app's `.env.local` / `.env`.
3. Apply `supabase/migrations/0001_initial_schema.sql` in the Supabase SQL editor.
4. Install dependencies in each app and run the relevant development command.

This is a starter scaffold, not a deployed or production-ready service. Add email templates, rate limits, moderation workflows, automated tests, and production secrets management before launch.
