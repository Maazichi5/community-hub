import Link from "next/link";

export default function Home() {
  return (
    <main className="shell">
      <nav className="nav"><strong className="brand">● Community Hub</strong><div><Link href="/auth">Sign in</Link><Link className="button small" href="/auth?mode=signup">Join Community</Link></div></nav>
      <section className="hero">
        <span className="eyebrow">CONNECT. SHARE. BELONG.</span>
        <h1>Your community,<br/><span>your voice.</span></h1>
        <p>Discover people, ideas and communities that matter. Share what inspires you and find your people.</p>
        <Link className="button" href="/auth?mode=signup">Create your account →</Link>
      </section>
      <section className="features">
        <article><b>Build connections</b><p>Meet people and follow conversations that matter to you.</p></article>
        <article><b>Share ideas</b><p>Publish updates and take part in thoughtful discussions.</p></article>
        <article><b>Join groups</b><p>Find communities around your interests and passions.</p></article>
      </section>
      <footer>Community Hub · A welcoming place for everyone.</footer>
    </main>
  );
}
