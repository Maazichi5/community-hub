'use client';

import { FormEvent, useState } from "react";
import { useSearchParams } from "next/navigation";
import { supabase } from "../../lib/supabase";

export default function AuthPage() {
  const params = useSearchParams();
  const [mode, setMode] = useState(params.get("mode") === "signup" ? "signup" : "signin");
  const [email, setEmail] = useState("");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [message, setMessage] = useState("");
  const [busy, setBusy] = useState(false);

  async function submit(e: FormEvent) {
    e.preventDefault(); setBusy(true); setMessage("");
    try {
      if (mode === "signup") {
        const { error } = await supabase.auth.signUp({
          email, password,
          options: { data: { username: username.trim().toLowerCase() } }
        });
        if (error) throw error;
        setMessage("Account request received. Check your email for a verification link.");
      } else {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
        setMessage("Signed in successfully. The member feed is the next feature to connect.");
      }
    } catch (err) {
      setMessage(err instanceof Error ? err.message : "Something went wrong.");
    } finally { setBusy(false); }
  }

  async function resetPassword() {
    if (!email) { setMessage("Enter your email address first."); return; }
    const { error } = await supabase.auth.resetPasswordForEmail(email);
    setMessage(error ? error.message : "If the address is registered, a password-reset email will be sent.");
  }

  return <main className="auth-wrap"><section className="auth-card">
    <a className="brand" href="/">● Community Hub</a>
    <p className="eyebrow">CONNECT. SHARE. BELONG.</p>
    <h1>{mode === "signup" ? "Create your account" : "Welcome back"}</h1>
    <p className="muted">{mode === "signup" ? "Join the community and make your voice heard." : "Sign in to continue your community journey."}</p>
    <form onSubmit={submit}>
      {mode === "signup" && <label>Username<input required minLength={3} maxLength={24} pattern="[A-Za-z0-9_]+" value={username} onChange={e=>setUsername(e.target.value)} placeholder="e.g. alex_01"/></label>}
      <label>Email address<input required type="email" autoComplete="email" value={email} onChange={e=>setEmail(e.target.value)} placeholder="you@example.com"/></label>
      <label>Password<input required type="password" minLength={8} autoComplete={mode === "signup" ? "new-password" : "current-password"} value={password} onChange={e=>setPassword(e.target.value)} placeholder="At least 8 characters"/></label>
      <button className="button full" disabled={busy}>{busy ? "Please wait…" : mode === "signup" ? "Create account" : "Sign in"}</button>
    </form>
    {mode === "signin" && <button className="text-button" onClick={resetPassword}>Forgot password?</button>}
    {message && <p role="status" className="message">{message}</p>}
    <p className="switch">{mode === "signup" ? "Already a member?" : "New to Community Hub?"} <button className="text-button" onClick={()=>{setMode(mode==="signup"?"signin":"signup");setMessage("");}}>{mode === "signup" ? "Sign in" : "Create an account"}</button></p>
  </section></main>;
}
