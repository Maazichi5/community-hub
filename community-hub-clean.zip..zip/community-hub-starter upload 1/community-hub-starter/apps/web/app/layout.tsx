import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Community Hub",
  description: "Connect. Share. Belong.",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}
