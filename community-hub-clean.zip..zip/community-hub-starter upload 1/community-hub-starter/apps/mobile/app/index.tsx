import { useState } from "react";
import { Alert, Pressable, StyleSheet, Text, TextInput, View } from "react-native";
import { supabase } from "../lib/supabase";

export default function AuthScreen() {
  const [mode,setMode] = useState<"signin"|"signup">("signin");
  const [email,setEmail] = useState(""); const [password,setPassword] = useState(""); const [username,setUsername] = useState("");
  const [busy,setBusy] = useState(false);
  async function submit() {
    setBusy(true);
    const result = mode === "signup"
      ? await supabase.auth.signUp({email,password,options:{data:{username:username.trim().toLowerCase()}}})
      : await supabase.auth.signInWithPassword({email,password});
    setBusy(false);
    Alert.alert(result.error ? "Unable to continue" : "Community Hub", result.error?.message ?? (mode==="signup" ? "Check your email to verify your account." : "Signed in successfully."));
  }
  return <View style={s.page}><View style={s.card}><Text style={s.brand}>● Community Hub</Text><Text style={s.tag}>CONNECT. SHARE. BELONG.</Text><Text style={s.title}>{mode==="signup"?"Create your account":"Welcome back"}</Text>
    {mode==="signup" && <TextInput style={s.input} placeholder="Username" autoCapitalize="none" value={username} onChangeText={setUsername}/>}
    <TextInput style={s.input} placeholder="Email address" keyboardType="email-address" autoCapitalize="none" value={email} onChangeText={setEmail}/>
    <TextInput style={s.input} placeholder="Password (8+ characters)" secureTextEntry value={password} onChangeText={setPassword}/>
    <Pressable style={s.button} onPress={submit} disabled={busy}><Text style={s.buttonText}>{busy?"Please wait…":mode==="signup"?"Create account":"Sign in"}</Text></Pressable>
    <Pressable onPress={()=>setMode(mode==="signup"?"signin":"signup")}><Text style={s.link}>{mode==="signup"?"Already a member? Sign in":"New here? Create an account"}</Text></Pressable>
  </View></View>;
}
const s=StyleSheet.create({page:{flex:1,backgroundColor:"#f6f8fc",justifyContent:"center",padding:22},card:{backgroundColor:"#fff",borderRadius:20,padding:25,borderWidth:1,borderColor:"#dce4f2"},brand:{fontSize:23,fontWeight:"800",color:"#10285f"},tag:{marginTop:8,color:"#1749c8",letterSpacing:2,fontSize:11,fontWeight:"700"},title:{fontSize:29,fontWeight:"800",color:"#10285f",marginVertical:25},input:{borderWidth:1,borderColor:"#dce4f2",borderRadius:10,padding:14,marginBottom:14,fontSize:16},button:{backgroundColor:"#1749c8",padding:16,borderRadius:11,alignItems:"center",marginTop:5},buttonText:{color:"#fff",fontWeight:"700",fontSize:16},link:{textAlign:"center",color:"#1749c8",fontWeight:"700",marginTop:22}});
