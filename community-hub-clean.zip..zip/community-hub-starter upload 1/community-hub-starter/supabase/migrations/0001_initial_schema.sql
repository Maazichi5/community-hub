-- Community Hub initial schema. Apply in a new Supabase project.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text unique not null check (char_length(username) between 3 and 24),
  display_name text,
  bio text default '',
  avatar_url text,
  is_private boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists public.posts (
  id uuid primary key default gen_random_uuid(),
  author_id uuid not null references public.profiles(id) on delete cascade,
  body text not null check (char_length(body) between 1 and 5000),
  visibility text not null default 'public' check (visibility in ('public','followers','private')),
  created_at timestamptz not null default now()
);

create table if not exists public.likes (
  user_id uuid not null references public.profiles(id) on delete cascade,
  post_id uuid not null references public.posts(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key(user_id, post_id)
);

create table if not exists public.comments (
  id uuid primary key default gen_random_uuid(),
  post_id uuid not null references public.posts(id) on delete cascade,
  author_id uuid not null references public.profiles(id) on delete cascade,
  body text not null check (char_length(body) between 1 and 2000),
  created_at timestamptz not null default now()
);

alter table public.profiles enable row level security;
alter table public.posts enable row level security;
alter table public.likes enable row level security;
alter table public.comments enable row level security;

create policy "Public profiles are viewable; private profiles by owner"
on public.profiles for select using (not is_private or auth.uid() = id);
create policy "Users create their own profile"
on public.profiles for insert with check (auth.uid() = id);
create policy "Users update their own profile"
on public.profiles for update using (auth.uid() = id) with check (auth.uid() = id);

create policy "Public posts are viewable"
on public.posts for select using (visibility = 'public' or auth.uid() = author_id);
create policy "Members create their own posts"
on public.posts for insert with check (auth.uid() = author_id);
create policy "Authors update their own posts"
on public.posts for update using (auth.uid() = author_id) with check (auth.uid() = author_id);
create policy "Authors delete their own posts"
on public.posts for delete using (auth.uid() = author_id);

create policy "Likes visible for public posts"
on public.likes for select using (exists (select 1 from public.posts p where p.id = post_id and p.visibility = 'public'));
create policy "Members like as themselves"
on public.likes for insert with check (auth.uid() = user_id);
create policy "Members remove their own likes"
on public.likes for delete using (auth.uid() = user_id);

create policy "Comments visible on public posts"
on public.comments for select using (exists (select 1 from public.posts p where p.id = post_id and p.visibility = 'public'));
create policy "Members comment as themselves"
on public.comments for insert with check (auth.uid() = author_id);
create policy "Authors delete their own comments"
on public.comments for delete using (auth.uid() = author_id);

-- Create a profile automatically when an auth user signs up.
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = ''
as $$
begin
  insert into public.profiles (id, username, display_name)
  values (
    new.id,
    coalesce(nullif(lower(new.raw_user_meta_data ->> 'username'), ''), 'member_' || substr(new.id::text, 1, 8)),
    coalesce(new.raw_user_meta_data ->> 'username', '')
  )
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
after insert on auth.users
for each row execute procedure public.handle_new_user();
